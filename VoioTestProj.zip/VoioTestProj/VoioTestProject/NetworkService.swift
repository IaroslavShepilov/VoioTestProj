//
//  NetworkService.swift
//  UpsideRebuild
//
//  Created by Yaroslav Shepilov on 12.05.2022.
//

import Foundation

public struct NetworkService {
    public static func request<T: Codable>(router: NetworkRequestProtocol, completion: @escaping (Result<T, Error>) -> ()) {
        var components = URLComponents()
        components.scheme = router.scheme
        components.host = router.host
        components.path = router.path
        if (!router.parameters.isEmpty) {
            components.queryItems = router.parameters
        }
        
        guard var url = components.url else {
            completion(.failure(NetworkError.invalidURL(urlPath: router.path)))
            return
        }
        if url.absoluteString.contains("$") {
            //let newUrlString = url.absoluteString.replacingOccurrences(of: "$", with: "%2C", options: .literal, range: nil)
            if let newUrl = URL(string: "https://youtube.googleapis.com/youtube/v3/channels?part=snippet%2CcontentDetails%2Cstatistics&id=UC_x5XG1OV2P6uZZ5FSM9Ttw%2CUCJKOvdk-nVzDAFR_9MF64sw%2CUCnksRRifsSCGUZpQukUKAyg%2CUC_1TiKyzQfiYlZlF8IqHv5w&key=AIzaSyCmfk9gia3fMwwMVdmucoMPwhLtzR2XnpQ") {
                url = newUrl
            }
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = router.method.rawValue
        let config = URLSessionConfiguration.default
        config.httpAdditionalHeaders = router.httpAdditionalHeader
        let session = URLSession(configuration: config)
        let dataTask = session.dataTask(with: urlRequest) { data, response, error in
            guard error == nil else {
                completion(.failure(error!))
                return
            }
            guard response != nil else {
                completion(.failure(NetworkError.emptyResponse(urlPath: url.absoluteString)))
                return
            }
            guard let responseData = data else {
                completion(.failure(NetworkError.emptyResponseData(urlPath: url.absoluteString)))
                return
            }
            do {
                if let responseString = String(data: responseData, encoding: .utf8) {
                    print("Received from URL:" + url.absoluteString + " response:" + responseString)
                }
                
                let responseObject = try JSONDecoder().decode(T.self, from: responseData)
                completion(.success(responseObject))
            } catch let error {
                completion(.failure(error))
            }
         }
         dataTask.resume()
     }
}
