//
//  NetworkConstants.swift
//  UpsideRebuild
//
//  Created by Yaroslav Shepilov on 12.05.2022.
//

import Foundation

public struct NetworkConstants {
 
    public enum Method: String {
        case GET = "GET"
        case POST = "POST"
    }
    
    public enum Path: String {
        case playlist = "/youtube/v3/playlists"
        case channels = "/youtube/v3/chanels"
        case videos = "/youtube/v3/search"
    }
    
    public static let apiKey = "AIzaSyCmfk9gia3fMwwMVdmucoMPwhLtzR2XnpQ"
    public static let scheme = "https"
    public static let host = "www.googleapis.com"
    
    public static func buildAuthHeader(with token: String) -> [String: String] {
        return ["authorization" : "Bearer \(token)"]
    }
}
