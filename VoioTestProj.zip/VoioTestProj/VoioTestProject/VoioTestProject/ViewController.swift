//
//  ViewController.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 10.05.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

