//
//  MainViewController.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 10.05.2022.
//

import UIKit
import SOPullUpView
import youtube_ios_player_helper
import Kingfisher

class MainViewController: UIViewController, UIScrollViewDelegate, SOPullUpViewDataSource {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var playlistNameLabel: UILabel!
    
    @IBOutlet weak var firstViewCollection: ViewCollection!
    @IBOutlet weak var secondViewCollection: ViewCollection!
    
    var channelInfo: ChannelInfo?
    
    private var model = MainViewModel()
    var pullUpController = SOPullUpControl()
    var frame: CGRect = .zero
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "YouTube API"
    
        scrollView.delegate = self
        scrollView.layer.cornerRadius = 5
        pullUpController.dataSource = self
        pullUpController.setupCard(from: view)
        firstViewCollection.delagate = self
        secondViewCollection.delagate = self
        self.model.delegate = self
        model.getPlaylists()
        model.getChanels()
        model.getVideos()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupNavigationBar()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navigationController?.navigationBar.sizeToFit()
        createTimer()
    }
        
    @IBAction func pageControlDidChanged(_ sender: UIPageControl) {
        let offset = CGPoint(x: scrollView.frame.size.width * CGFloat(pageControl.currentPage) , y: 0)
        scrollView.setContentOffset(offset, animated: true)
    }
    
    func createTimer() {
        let timer = Timer.scheduledTimer(timeInterval: 5.0,
                                         target: self,
                                         selector: #selector(fireTimer),
                                         userInfo: nil, repeats: true)
        DispatchQueue.main.async {
            timer.fire()
        }
    }
    
    @objc func fireTimer() {
        var nextPage = pageControl.currentPage + 1
        print(nextPage)
        if nextPage >= pageControl.numberOfPages {
            nextPage = 0
        }
        pageControl.currentPage = nextPage
        let offset = CGPoint(x: scrollView.frame.size.width * CGFloat(pageControl.currentPage) , y: 0)
        scrollView.setContentOffset(offset, animated: true)
    }
    
    func pullUpViewCollapsedViewHeight() -> CGFloat {
        return 40 + 34
    }
    
    func pullUpViewController() -> UIViewController {
        let vc = PlayerViewController()
        vc.pullUpControl = self.pullUpController
        return vc
    }
    
    func setupScreens(items: [ChannelInfo]) {
        
        pageControl.numberOfPages = items.count
        for (index, chanel) in items.enumerated() {
            frame.origin.x = scrollView.frame.size.width * CGFloat(index)
            frame.size = scrollView.frame.size
            let imageInfo = chanel.snippet.thumbnails.high
            let url = URL(string: imageInfo.url)
            let customView = CustomView(frame: frame)
            customView.setupChanelInfo(image: url, titleForChanelName: "\(chanel.snippet.title)", titleForSubsCount: "\(chanel.statistics.subscriberCount)" + " " + "подписчика")
            self.scrollView.addSubview(customView)
        }
        scrollView.contentSize = CGSize(width: (scrollView.frame.size.width * CGFloat(items.count)), height: scrollView.frame.size.height)
        scrollView.delegate = self
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
        pageControl.currentPage = Int(pageNumber)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.scrollView.contentOffset = .init(x: scrollView.contentOffset.x, y: 0)
    }
}

private extension MainViewController {
    func setupNavigationBar() {
        navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationController?.navigationItem.largeTitleDisplayMode = .always
        let navBarAppearance = UINavigationBarAppearance()
        navBarAppearance.configureWithOpaqueBackground()
        navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        navBarAppearance.backgroundColor = .clear
        navigationController?.navigationBar.standardAppearance = navBarAppearance
        navigationController?.navigationBar.scrollEdgeAppearance = navBarAppearance
    }
    
    func map(_ items: [VideoInfo]) -> [ViewCollectionModel] {
        return items.map { videoInfo -> ViewCollectionModel in
            let snippet = videoInfo.snippet
            let imageInfo = snippet.thumbnails
            let imageUrlString = imageInfo.high.url
            return ViewCollectionModel(
                urlImage: imageUrlString,
                urlVideo: videoInfo.id.videoId,
                title: snippet.title,
                subtitle: ""
            )
        }
    }
}

extension MainViewController: MainViewModelProtocol {
    func updateFirstCollection(with response: GetVideosResponse) {
        firstViewCollection.setup(width: 140, items: map(response.items))
    }
    
    func updateSecondCollection(with response: GetVideosResponse) {
        secondViewCollection.setup(width: 100, items: map(response.items))
    }
    
    func updatePlaylistResponse(response: GetPlaylistsResponse) {
    }
    
    func updateChannelsResponse(response: GetChannelsResponse) {
        setupScreens(items: response.items)
    }
}

extension MainViewController: ViewCollectionProtocol {
    func setupVideo(videoURL: String) {
        print(videoURL)
    }
}
