//
//  ViewCollection.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 15.05.2022.
//

import UIKit
import Kingfisher

protocol ViewCollectionProtocol {
    func setupVideo(videoURL: String)
}

struct ViewCollectionModel {
    let urlImage: String?
    let urlVideo: String?
    let title: String
    let subtitle: String
}

class ViewCollection: UIView  {

    @IBOutlet var contentView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    var delagate: ViewCollectionProtocol?
    private var dataSource = [ViewCollectionModel]()
    var width: CGFloat = 0

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
    
    fileprivate func commonInit() {
        let viewFromXib = Bundle.main.loadNibNamed("ViewCollection", owner: self, options: nil)![0] as! UIView
        viewFromXib.frame = self.bounds
        addSubview(viewFromXib)
        self.backgroundColor = .clear
        setupCollectionView()
    }
    
    private func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib.init(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "collectionReusableCell")
    }
    
    func setup(width: CGFloat, items: [ViewCollectionModel]) {
        self.width = width
        self.dataSource = items
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegate

extension ViewCollection: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: width, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let info = dataSource[indexPath.row].urlVideo
        self.delagate?.setupVideo(videoURL: info ?? "")
    }
}
// MARK: - UICollectionViewDataSource
extension ViewCollection: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionReusableCell", for: indexPath) as! CollectionViewCell
        let info = dataSource[indexPath.row]
        let url = URL(string: info.urlImage ?? "")
        cell.imageView.kf.setImage(with: url)
        cell.imageView.contentMode = .scaleAspectFill
        cell.nameOfSongLabel.text = info.title
        cell.viewCountLabel.text = info.subtitle
        return cell
    }
}

