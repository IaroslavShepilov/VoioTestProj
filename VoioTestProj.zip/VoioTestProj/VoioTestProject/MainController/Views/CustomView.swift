//
//  CustomView.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 15.05.2022.
//

import UIKit
import Kingfisher

class CustomView: UIView {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var smallView: UIView!
    @IBOutlet weak var chanelNameLabel: UILabel!
    @IBOutlet weak var subsCountLabel: UILabel!
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
    
    fileprivate func commonInit() {
        let viewFromXib = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)![0] as! UIView
        viewFromXib.frame = self.bounds
        addSubview(viewFromXib)
        smallView.layer.cornerRadius = 8
    }
    
    func setupChanelInfo(image: URL?, titleForChanelName: String, titleForSubsCount: String) {
        imageView.kf.setImage(with: image)
        chanelNameLabel.text = titleForChanelName
        subsCountLabel.text = titleForSubsCount
    }
}
