//
//  CollectionViewCell.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 14.05.2022.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameOfSongLabel: UILabel!
    @IBOutlet weak var viewCountLabel: UILabel!
  
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        imageView.layer.cornerRadius = 12
    }
}
