//
//  ModelMainController.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 10.05.2022.
//

import Foundation

protocol MainViewModelProtocol {
    func updatePlaylistResponse(response: GetPlaylistsResponse)
    func updateChannelsResponse(response: GetChannelsResponse)
    func updateFirstCollection(with response: GetVideosResponse)
    func updateSecondCollection(with response: GetVideosResponse)
}

final class MainViewModel {
    var delegate: MainViewModelProtocol?
    private let defaultChannels = ["UC_x5XG1OV2P6uZZ5FSM9Ttw","UCJKOvdk-nVzDAFR_9MF64sw","UCnksRRifsSCGUZpQukUKAyg","UC_1TiKyzQfiYlZlF8IqHv5w"]

    func getPlaylists() {
        NetworkService.request(router: GetPlaylistsRequest()) { [weak self] (result: Result<GetPlaylistsResponse, Error>) in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    self?.delegate?.updatePlaylistResponse(response: response)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func getChanels() {
        NetworkService.request(router: GetChannelsRequest(channelIds: defaultChannels)) { (result: Result<GetChannelsResponse, Error>) in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    self.delegate?.updateChannelsResponse(response: response)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func getVideos() {
        getVideo(for: defaultChannels[0]) { [weak self] response in
            self?.delegate?.updateFirstCollection(with: response)
        }
        getVideo(for: defaultChannels[1]) { [weak self] response in
            self?.delegate?.updateSecondCollection(with: response)
        }
    }
    
    private func getVideo(for channelId: String, completion: ((GetVideosResponse) -> Void)?) {
        NetworkService.request(router: GetVideosRequest(channelId: channelId)) { (result: Result<GetVideosResponse, Error>) in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    completion?(response)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

