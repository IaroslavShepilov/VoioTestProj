//
//  PlayerViewController.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 10.05.2022.
//

import UIKit
import SOPullUpView
import AVFoundation
    
class PlayerViewController: UIViewController, SOPullUpViewDelegate {
    
    var pullUpControl: SOPullUpControl? {
        didSet {
            pullUpControl?.delegate = self
        }
    }
    
    var url: String? {
        didSet {
            print("test")
        }
    }
    
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var previousSongButton: UIButton!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var nextSongButton: UIButton!
    @IBOutlet weak var soundSlider: UISlider!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var viewCountLabel: UILabel!
    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var timeSlider: UISlider!

    var player: AVPlayer!
    var playerLayer: AVPlayerLayer!
    var isVideoPlaying = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string: "https://content.jwplatform.com/manifests/vM7nH0Kl.m3u8")!
        player = AVPlayer(url: url)
        player.currentItem?.addObserver(self, forKeyPath: "duration", options: [.new, .initial], context: nil)
        addTimeObserver()
        playerLayer = AVPlayerLayer(player: player)
        playerLayer.videoGravity = .resize
        playerView.layer.addSublayer(playerLayer)
        timeSlider.setThumbImage(thumbImage(), for: .normal)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer.frame = playerView.bounds
    }
    
    private func thumbImage() -> UIImage {
            let view = UIView(frame: CGRect(x: 0, y: 0, width: 3, height: 14))
            view.backgroundColor = .white
            let renderer = UIGraphicsImageRenderer(bounds: view.bounds)
            return renderer.image { rendererContext in
                view.layer.render(in: rendererContext.cgContext)
            }
        }
    
    func addTimeObserver() {
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        let mainQueue = DispatchQueue.main
        _ = player.addPeriodicTimeObserver(forInterval: interval, queue: mainQueue, using: { [weak self]
            time in
            guard let currentItem = self?.player.currentItem else {return}
            self?.timeSlider.maximumValue = Float(currentItem.duration.seconds)
            self?.timeSlider.minimumValue = 0
            self?.timeSlider.value = Float(currentItem.currentTime().seconds)
            self?.currentTimeLabel.text = self?.getTimeString(from: currentItem.currentTime())
        })
    }
    
    @IBAction func pauseAction(_ sender: Any) {
        setupPlayPause(isPlay: !isVideoPlaying)
    }
    
    @IBAction func volumeChangedAction(_ sender: Any) {
        let volume = Float(soundSlider.value)
        player.volume = volume
        print(volume)
    }
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        player.seek(to: CMTimeMake(value: Int64(Int(sender.value*1000)), timescale: 1000))
    }
    
    func setupPlayButton() {
        if isVideoPlaying {
          pauseButton.setImage(UIImage(named: "Pause"), for: .normal)
        } else {
            pauseButton.setImage(UIImage(named: "Play"), for: .normal)
        }
    }
    
    func setupPlayPause(isPlay: Bool) {
        if isPlay {
            isVideoPlaying = true
            player.play()
        } else {
            isVideoPlaying = false
            player.pause()
        }
        setupPlayButton()
    }

    func pullUpViewStatus(_ sender: UIViewController, didChangeTo status: PullUpStatus) {
        switch status {
          case .collapsed:
//            setupPlayPause(isPlay: false)
//            спочатку паузи ставив, коли відкривався та закривався pullupControl, але прибираю, щоб було схоже на youtube, де відкрите відео програється в звернутому вигляді
            print("collapsed")
          case .expanded:
//            setupPlayPause(isPlay: true)
            print("expanded")
       }
        setupPlayButton()
    }
    
    func pullUpHandleArea(_ sender: UIViewController) -> UIView {
        return view
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change:
                                [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "duration", let duration = player.currentItem?.duration.seconds, duration > 0.0 {
            self.durationLabel.text = getTimeString(from: player.currentItem!.duration)
        }
    }
    
    func getTimeString(from time: CMTime) -> String {
        let totalSeconds = CMTimeGetSeconds(time)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        if hours > 0 {
            return String(format: "%i:%02i:%02i", arguments: [hours, minutes, seconds])
        } else { 
            return String(format: "%02i:%02i", arguments: [minutes, seconds])
        }
    }
}

// AVPlayer не може програвати стрімінгові відео (лише локальні), залишив його просто для зразка, сюди потрібно було б передати array з плейлистів та пидключіті next i previous buttons по nextPageToken з GetVideosResponse

