//
//  NetworkManager.swift
//  VoioTestProject
//
//  Created by Dmitriy Ponomarenko on 10.05.2022.
//

import Foundation

var myYoutubeApiKey = "AIzaSyCmfk9gia3fMwwMVdmucoMPwhLtzR2XnpQ"
