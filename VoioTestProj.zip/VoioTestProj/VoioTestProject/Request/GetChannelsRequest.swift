//
//  File.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 12.05.2022.
//

import Foundation

struct GetChannelsRequest: NetworkRequestProtocol {
    var scheme: String = NetworkConstants.scheme
    var host: String = NetworkConstants.host
    var path: String = NetworkConstants.Path.channels.rawValue
    var parameters: [URLQueryItem] = [
        URLQueryItem(name: "key",value: NetworkConstants.apiKey),
        URLQueryItem(name: "maxResults", value: "10")
    ]
    var method: NetworkConstants.Method = .GET
    var httpAdditionalHeader: [String : String] = [:]
    
    init(channelIds: [String]) {
        let parts = ["snippet", "contentDetails", "statistics"]
        let partsValue = parts.joined(separator: "$")
        parameters.append(URLQueryItem(name: "part", value: partsValue))
        
        let channelsValue = channelIds.joined(separator: "$")
        parameters.append(URLQueryItem(name: "id", value: channelsValue))
        
        // коли формую string, де є "," (перелік з декількох параметрів), то URLQuery неправильно форматує (замисть "," потрібно "%2C"), тому зробив workaround із символом "$" та замінюю фінальну url 
    }
}


