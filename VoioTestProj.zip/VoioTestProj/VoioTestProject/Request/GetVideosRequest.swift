//
//  GetVideosRequest.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 17.05.2022.
//

import Foundation

struct GetVideosRequest: NetworkRequestProtocol {
    var scheme: String = NetworkConstants.scheme
    var host: String = NetworkConstants.host
    var path: String = NetworkConstants.Path.videos.rawValue
    var parameters: [URLQueryItem] = [
        URLQueryItem(name: "part",value: "snippet,id"),
        URLQueryItem(name: "key",value: NetworkConstants.apiKey),
        URLQueryItem(name: "order", value: "date"),
        URLQueryItem(name: "maxResults", value: "10")
    ]
    var method: NetworkConstants.Method = .GET
    var httpAdditionalHeader: [String : String] = [:]
    
    init(channelId: String) {
        parameters.append(URLQueryItem(name: "channelId",value: channelId))
    }
}
