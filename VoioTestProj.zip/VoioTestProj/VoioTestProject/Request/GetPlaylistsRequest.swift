//
//  GetUserRequest.swift
//  UpsideRebuild
//
//  Created by Yaroslav Shepilov on 14.05.2022.
//

import Foundation

struct GetPlaylistsRequest: NetworkRequestProtocol {
    var scheme: String = NetworkConstants.scheme
    var host: String = NetworkConstants.host
    var path: String = NetworkConstants.Path.playlist.rawValue
    var parameters: [URLQueryItem] = [
        URLQueryItem(name: "part",value: "snippet"),
        URLQueryItem(name: "channelId",value: "UCJKOvdk-nVzDAFR_9MF64sw"),
        URLQueryItem(name: "key",value: NetworkConstants.apiKey),
        URLQueryItem(name: "maxResults", value: "10")
    ]
    var method: NetworkConstants.Method = .GET
    var httpAdditionalHeader: [String : String] = [:]
}



