//
//  File.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 12.05.2022.
//

import Foundation

struct GetChannelsResponse: Codable {
    let kind: String
    let etag: String
    let pageInfo: PageInfo
    let items: [ChannelInfo]
}

struct ChannelInfo: Codable {
    let kind: String
    let etag: String
    let id: String
    let snippet: SnippetInfoChannel
    let contentDetails: ContentDetailsInfo
    let statistics: StatisticsINfo
}

struct SnippetInfoChannel: Codable {
    let title: String
    let description: String
    let customUrl: String?
    let publishedAt: String
    let thumbnails: ThumbnailsInfoChannel
    let localized: LocalizedInfo
    let country: String
}

struct ContentDetailsInfo: Codable {
    let relatedPlaylists: RelatedPlaylists
}

struct RelatedPlaylists:Codable {
    let likes: String
    let uploads: String
}

struct StatisticsINfo: Codable {
    let viewCount: String
    let subscriberCount: String
    let hiddenSubscriberCount: Bool
    let videoCount: String
}
struct ThumbnailsInfoChannel: Codable {
    let defaultInfo: UrlInfo
    let medium: UrlInfo
    let high: UrlInfo
    
    enum CodingKeys: String, CodingKey {
        case defaultInfo = "default"
        case medium
        case high

    }
}
