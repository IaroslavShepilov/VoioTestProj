//
//  GetPlaylistsResponse.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 14.05.2022.
//

import Foundation

struct GetPlaylistsResponse: Codable {
    let kind: String
    let etag: String
    let nextPageToken: String
    let pageInfo: PageInfo
    let items: [PlaylistInfo]
}

struct PageInfo: Codable {
    let totalResults: Int
    let resultsPerPage: Int
}

struct PlaylistInfo: Codable {
    let kind: String
    let etag: String
    let id: String
    let snippet: SnippetInfo
}

struct SnippetInfo: Codable {
    let publishedAt: String
    let channelId: String
    let title: String
    let description: String
    let thumbnails: ThumbnailsInfo
    let channelTitle: String
    let localized: LocalizedInfo
}

struct LocalizedInfo: Codable {
    let title: String
    let description: String
}

struct ThumbnailsInfo: Codable {
    let defaultInfo: UrlInfo
    let medium: UrlInfo
    let high: UrlInfo
    let standard: UrlInfo
    let maxres: UrlInfo?
   
    enum CodingKeys: String, CodingKey {
        case defaultInfo = "default"
        case medium
        case high
        case standard
        case maxres
    }
}

struct UrlInfo: Codable {
    let url: String
    let width: Int
    let height: Int
}
