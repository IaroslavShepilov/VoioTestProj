//
//  GetVideosResponse.swift
//  VoioTestProject
//
//  Created by Yaroslav Shepilov on 17.05.2022.
//

import Foundation

struct GetVideosResponse: Codable {
    let kind: String
    let etag: String
    let nextPageToken: String
    let regionCode: String
    let pageInfo: PageInfo
    let items: [VideoInfo]
}

struct VideoInfo: Codable {
    let kind: String
    let etag: String
    let id: IdInfoVideo
    let snippet: SnippetInfoVideo
}

struct IdInfoVideo: Codable {
    let kind: String
    let videoId: String
}

struct SnippetInfoVideo: Codable {
    let publishedAt: String
    let channelId: String
    let title: String
    let description: String
    let thumbnails: ThumbnailsInfoChannel
    let channelTitle: String?
    let liveBroadcastContent: String
    let publishTime: String
}


